package kim;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JToolBar;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTree;
import javax.swing.JTextPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class kim extends JFrame {
	private JTextField txtFdf;
	private JTextField txtId;
	private JTextField txtPassword;
	private JPasswordField passwordField;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					kim frame = new kim();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public kim() {
		getContentPane().setBackground(new Color(245, 245, 220));
		getContentPane().setLayout(null);
		
		txtFdf = new JTextField();
		txtFdf.setText("    Hub Chating");
		txtFdf.setFont(new Font("Yu Gothic Light", Font.PLAIN, 24));
		txtFdf.setBackground(new Color(192, 192, 192));
		txtFdf.setBounds(33, 38, 192, 39);
		getContentPane().add(txtFdf);
		txtFdf.setColumns(10);
		
		txtId = new JTextField();
		txtId.setBackground(new Color(245, 245, 220));
		txtId.setText("ID");
		txtId.setBounds(48, 259, 21, 21);
		getContentPane().add(txtId);
		txtId.setColumns(10);
		
		txtPassword = new JTextField();
		txtPassword.setBackground(new Color(245, 245, 220));
		txtPassword.setText("P.W");
		txtPassword.setBounds(41, 290, 28, 21);
		getContentPane().add(txtPassword);
		txtPassword.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(81, 290, 82, 21);
		getContentPane().add(passwordField);
		
		textField = new JTextField();
		textField.setBounds(81, 259, 82, 21);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBounds(175, 259, 71, 52);
		getContentPane().add(btnNewButton);
		
	}
}
